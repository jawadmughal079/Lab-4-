#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{
    const int size = 11;
    int i = 0;
    int numberOfPlayers[size];
    int MatchPlayedByPlayers[size];
    int iningsPlayedByPlayers[size];
    int totalScoreOfPlayers[size];
    int highestScoreOfPlayers[size];
    float averageOfPlayers[size];
    float strikeRateOfPlayers[size];
    int hunderdsOfPlayers[size];
    int fiftiesOfPlayers[size];
    // file taking prosssess is

    // for name
    ifstream names("names.txt");
    string namesOfPlayers[size];
    for (int i = 0; i < size; i++)
    {
        getline(names, namesOfPlayers[i]);
    }

    int indexOfruns = 0;
    ifstream dataOfPlayers("PlayersStats.txt");
    while (!dataOfPlayers.eof())
    {
        dataOfPlayers << numberOfPlayers[i];
        dataOfPlayers << MatchPlayedByPlayers[i];
        dataOfPlayers << iningsPlayedByPlayers[i];
        dataOfPlayers << totalScoreOfPlayers[i];
        dataOfPlayers << highestScoreOfPlayers[i];
        dataOfPlayers << averageOfPlayers[i];
        dataOfPlayers << strikeRateOfPlayers[i];
        dataOfPlayers << hunderdsOfPlayers[i];
        dataOfPlayers << fiftiesOfPlayers[i];
        i++;
    }

    int select = 0; // it is use here to make a menu option
    cout << " PRESS 1 TO  PAKISTANI TEAM INFO \n";
    cout << " PRESS 2 THE BATTER WHO HAVING MAXIMUM RUNS SO FAT \n";
    cout << " PRESS 3 THE BATTER WHOSE STRIKE RATE ARE IN BETWEEN 130.0 AND 150.0 FAR. \n";
    cout << " PRESS 4 BATTERS WHO APPEARS IN LESS THAN 50 MATCHES \n";
    cout << " PRESS 5 BATTER WHOSE HAVING MAXIUM NUMBER OF FIFTIES \n";

    cin >> select;
    if (select == 1)
    {

        int press = 0;
        cout << " PRESS NUMBERS OF PLAYERS  TO SEE DETIAL OF  PLAYERS \n";
        cout << "1-Babar Azam\n2-Muhammad Rizwan\n3-Fakhar Zaman\n"
                "4-Muhammad Hafeez\n5-Shoaib Malik\n6-Asif Ali\n"
                "7-Imad Wasim\n8-Shadab Khan\n9-Hassan Ali\n"
                "10-Harris Rauf\n11-Shahen Shah Afridi\n";
        cin >> press;
        dataOfPlayers << numberOfPlayers[press - 1];
        dataOfPlayers << MatchPlayedByPlayers[press - 1];
        dataOfPlayers << iningsPlayedByPlayers[press - 1];
        dataOfPlayers << totalScoreOfPlayers[press - 1];
        dataOfPlayers << highestScoreOfPlayers[press - 1];
        dataOfPlayers << averageOfPlayers[press - 1];
        dataOfPlayers << strikeRateOfPlayers[press - 1];
        dataOfPlayers << hunderdsOfPlayers[press - 1];
        dataOfPlayers << fiftiesOfPlayers[press - 1];
    }

    else if (select == 2)
    {

        cout << "-----------------------------------------------------------------------------------\n";
        cout << " THE BATTER WHO HAVING MAXIMUM RUNS SO FAR.\n";
        cout << "-----------------------------------------------------------------------------------\n";
        cout << endl;
        int max = totalScoreOfPlayers[0];
        for (int i = 0; i < size; i++)
        {
            if (max < totalScoreOfPlayers[i])
            {
                max = totalScoreOfPlayers[i];
                indexOfruns = i;
            }
        }
        cout << endl;
        cout << "-----------------------------------------------------------------------------------\n";
        cout << "PLAYER NAME IS :" << namesOfPlayers[indexOfruns] << endl;
        cout << "-----------------------------------------------------------------------------------\n";
        cout << "NUMBER OF PLAYERS IS  :" << numberOfPlayers[indexOfruns];
        cout << endl;
        cout << "PLAYER RUNS IS :" << totalScoreOfPlayers[indexOfruns];
        cout << endl;
        cout << "TOTAL MATCH PLAYED :" << MatchPlayedByPlayers[indexOfruns];
        cout << endl;
        cout << "TOTAL INNINGS PLAYED :" << iningsPlayedByPlayers[indexOfruns];
        cout << endl;
        cout << "AVERAGE OF PLAYER :" << averageOfPlayers[indexOfruns];
        cout << endl;
        cout << "STRIKE RATE OF PLAYER :" << strikeRateOfPlayers[indexOfruns];
        cout << endl;
        cout << "FIFTES OF  PLAYER :" << fiftiesOfPlayers[indexOfruns];
        cout << endl;
        cout << "HUNDERED OF PLAYER :" << hunderdsOfPlayers[indexOfruns];
        cout << endl;
        cout << "HIGEST SCORE OF PLAYER :" << highestScoreOfPlayers[indexOfruns];
        cout << endl;
        indexOfruns = 0;
    }
    else if (select == 3)
    {

        cout << "-----------------------------------------------------------------------------------\n";
        cout << " THE BATTER WHOSE STRIKE RATE ARE IN BETWEEN 130.0 AND 150.0 FAR.\n";
        cout << "-----------------------------------------------------------------------------------\n";

        int storeMaxStrickRate = strikeRateOfPlayers[0];
        bool flagForMaxStrikeRun = 0;
        for (int i = 0; i < size; i++)
        {
            flagForMaxStrikeRun = 0;
            if (strikeRateOfPlayers[i] > 130.0 && strikeRateOfPlayers[i] < 150.0)
            {
                indexOfruns = i;
                flagForMaxStrikeRun = 1;
            }
            if (flagForMaxStrikeRun == 1)
            {
                cout << endl;
                cout << "-----------------------------------------------------------------------------------\n";
                cout << "PLAYER NAME IS :" << namesOfPlayers[indexOfruns] << endl;
                cout << "-----------------------------------------------------------------------------------\n";
                cout << "NUMBER OF PLAYERS IS  :" << numberOfPlayers[indexOfruns];
                cout << endl;
                cout << "PLAYER RUNS IS :" << totalScoreOfPlayers[indexOfruns];
                cout << endl;
                cout << "TOTAL MATCH PLAYED :" << MatchPlayedByPlayers[indexOfruns];
                cout << endl;
                cout << "TOTAL INNINGS PLAYED :" << iningsPlayedByPlayers[indexOfruns];
                cout << endl;
                cout << "AVERAGE OF PLAYER :" << averageOfPlayers[indexOfruns];
                cout << endl;
                cout << "STRIKE RATE OF PLAYER :" << strikeRateOfPlayers[indexOfruns];
                cout << endl;
                cout << "FIFTES OF  PLAYER :" << fiftiesOfPlayers[indexOfruns];
                cout << endl;
                cout << "HUNDERED OF PLAYER :" << hunderdsOfPlayers[indexOfruns];
                cout << endl;
                cout << "HIGEST SCORE OF PLAYER :" << highestScoreOfPlayers[indexOfruns];
                cout << endl;
                cout << "--------------------------------------------------------------------------\n";
                indexOfruns = 0;
            }
        }
    }

    else if (select == 4)
    {

        cout << "-----------------------------------------------------------------------------------\n";
        cout << "BATTERS WHO APPEARS IN LESS THAN 50 MATCHES \n";
        cout << "-----------------------------------------------------------------------------------\n";
        cout << endl;
        cout << endl;
        int lessMatchesThanFifty = 50;

        bool flagForlessMatchesThanFifty = 0;
        // for loop use there to find matches less than 50
        for (int i = 0; i < size; i++)
        {
            flagForlessMatchesThanFifty = 0;
            if (MatchPlayedByPlayers[i] < lessMatchesThanFifty)
            {
                indexOfruns = i;
                flagForlessMatchesThanFifty = 1;
            }
            if (flagForlessMatchesThanFifty == 1)
            {
                cout << endl;
                cout << "-----------------------------------------------------------------------------------\n";
                cout << "PLAYER NAME IS :" << namesOfPlayers[indexOfruns] << endl;
                cout << "-----------------------------------------------------------------------------------\n";
                cout << "NUMBER OF PLAYERS IS  :" << numberOfPlayers[indexOfruns];
                cout << endl;
                cout << "PLAYER RUNS IS :" << totalScoreOfPlayers[indexOfruns];
                cout << endl;
                cout << "TOTAL MATCH PLAYED :" << MatchPlayedByPlayers[indexOfruns];
                cout << endl;
                cout << "TOTAL INNINGS PLAYED :" << iningsPlayedByPlayers[indexOfruns];
                cout << endl;
                cout << "AVERAGE OF PLAYER :" << averageOfPlayers[indexOfruns];
                cout << endl;
                cout << "STRIKE RATE OF PLAYER :" << strikeRateOfPlayers[indexOfruns];
                cout << endl;
                cout << "FIFTES OF  PLAYER :" << fiftiesOfPlayers[indexOfruns];
                cout << endl;
                cout << "HUNDERED OF PLAYER :" << hunderdsOfPlayers[indexOfruns];
                cout << endl;
                cout << "HIGEST SCORE OF PLAYER :" << highestScoreOfPlayers[indexOfruns];
                cout << endl;
                cout << "--------------------------------------------------------------------------\n";
            }
        }
        indexOfruns = 0;
    }
    else if (select == 5)
    {
        cout << "-----------------------------------------------------------------------------------\n";
        cout << "BATTER WHOSE HAVING MAXIUM NUMBER OF FIFTIES \n";
        cout << "-----------------------------------------------------------------------------------\n";

        int maxFitiesFinder = fiftiesOfPlayers[0];

        for (int i = 0; i < size; i++)
        {

            if (maxFitiesFinder < fiftiesOfPlayers[i])
            {
                maxFitiesFinder = fiftiesOfPlayers[i];
                indexOfruns = i;
            }
        }
        cout << endl;
        cout << "-----------------------------------------------------------------------------------\n";
        cout << "PLAYER NAME IS :" << namesOfPlayers[indexOfruns] << endl;
        cout << "-----------------------------------------------------------------------------------\n";
        cout << "NUMBER OF PLAYERS IS  :" << numberOfPlayers[indexOfruns];
        cout << endl;
        cout << "PLAYER RUNS IS :" << totalScoreOfPlayers[indexOfruns];
        cout << endl;
        cout << "TOTAL MATCH PLAYED :" << MatchPlayedByPlayers[indexOfruns];
        cout << endl;
        cout << "TOTAL INNINGS PLAYED :" << iningsPlayedByPlayers[indexOfruns];
        cout << endl;
        cout << "AVERAGE OF PLAYER :" << averageOfPlayers[indexOfruns];
        cout << endl;
        cout << "STRIKE RATE OF PLAYER :" << strikeRateOfPlayers[indexOfruns];
        cout << endl;
        cout << "FIFTES OF  PLAYER :" << fiftiesOfPlayers[indexOfruns];
        cout << endl;
        cout << "HUNDERED OF PLAYER :" << hunderdsOfPlayers[indexOfruns];
        cout << endl;
        cout << "HIGEST SCORE OF PLAYER :" << highestScoreOfPlayers[indexOfruns];
        cout << endl;
        indexOfruns = 0;
    }

    return 0;
}
